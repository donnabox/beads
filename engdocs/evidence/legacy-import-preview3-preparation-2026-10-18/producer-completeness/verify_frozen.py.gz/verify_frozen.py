#!/usr/bin/env python3
"""Independently verify the synthetic ordinary producer corpus and local controls."""

from __future__ import annotations

import hashlib
import json
import os
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent
CLONE = Path("/Users/dbox/.local/state/iris/producer-private-20261018")
SOURCE = "76fde9c9cb0865d430bf12d76fc473490f51128a"
TREE = "80d2aeb1146a7b3075fbed7a75e31f253032207c"
GENERATOR_SHA = "fa0335aa8fd098ee0c8459f5d36ca4937a8689bb852a2c4eaabaf5512549aa43"
KEYS = {
    "fixture-key", "has space", "has%20space", " leading", "trailing ", "記憶",
    "%E8%A8%98%E6%86%B6", "100%", ".", "..", "path/part",
    "double//separator", "back\\slash", "tab\tline\nbreak", "web-app-a1b",
    "empty-value",
}


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for part in iter(lambda: f.read(1024 * 1024), b""):
            h.update(part)
    return h.hexdigest()


def git(*args: str) -> str:
    return subprocess.check_output(["git", "-C", str(CLONE), *args], text=True).strip()


def main() -> None:
    assert (CLONE / ".git").is_dir()
    assert not (CLONE / ".git" / "commondir").exists()
    assert not (CLONE / ".git" / "objects" / "info" / "alternates").exists()
    assert git("rev-parse", "HEAD") == SOURCE
    assert git("rev-parse", "HEAD^{tree}") == TREE
    assert git("status", "--porcelain") == ""
    assert git("config", "--local", "core.abbrev") == "12"

    generator = ROOT / "generator.py"
    binary = ROOT / "install" / "bd"
    fixture = ROOT / "corpus" / "ordinary.jsonl"
    receipt_file = ROOT / "corpus" / "producer.json"
    assert sha(generator) == GENERATOR_SHA
    assert binary.is_file() and fixture.is_file() and receipt_file.is_file()
    assert sha(binary) == (ROOT / "binary.sha256").read_text().split()[0]
    receipt = json.loads(receipt_file.read_text())
    assert receipt["producerSource"] == SOURCE and receipt["producerSourceTree"] == TREE
    assert receipt["sourceState"] == "clean checkout; canonical make install-force build"
    assert receipt["binarySHA256"] == sha(binary)
    assert receipt["fixtureSHA256"] == sha(fixture)
    assert receipt["profile"] == "completeness" and receipt["issuePrefix"] == "web-app"
    assert "synthetic" in receipt["data"] and all(x["code"] == 0 for x in receipt["receipts"])
    versions = [x for x in receipt["receipts"] if x["args"] == ["version", "--json"]]
    assert len(versions) == 1
    version = json.loads(versions[0]["stdout"])
    assert version["commit"] == SOURCE and version["build"] == "76fde9c9cb08"
    assert receipt["producerVersion"] == "bd version 1.3.0 (76fde9c9cb08: 76fde9c9cb08)\n"

    build = (ROOT / "logs" / "binary-buildinfo.stdout").read_text()
    direct_build = subprocess.check_output(["go", "version", "-m", str(binary)], text=True)
    assert direct_build == build
    assert all(x in build for x in (
        "go1.26.7", "-tags=gms_pure_go", f"vcs.revision={SOURCE}",
        "vcs.modified=false", "github.com/dolthub/dolt/go",
        "github.com/dolthub/go-mysql-server",
    ))
    runner = json.loads((ROOT / "runner-receipts.json").read_text())
    assert len(runner) >= 20 and all(x["exit"] == 0 for x in runner)
    scrubbed = {k: v for k, v in os.environ.items()
                if not k.startswith(("BD_", "BEADS_", "DOLT_", "GIT_"))}
    direct_version = subprocess.check_output([str(binary), "version", "--json"],
                                             env=scrubbed, text=True)
    assert json.loads(direct_version) == version
    assert [x for x in runner if x["label"] == "make-install-force"][0]["argv"][-1] == "install-force"
    for x in runner:
        assert sha(Path(x["stdout"])) == x["stdoutSHA256"], x["label"]
        assert sha(Path(x["stderr"])) == x["stderrSHA256"], x["label"]
    assert json.loads((ROOT / "runner-result.json").read_text())["status"] == "PASS"

    records = [json.loads(line) for line in fixture.read_text().splitlines()]
    assert len(records) == 20
    issues = [x for x in records if x["_type"] == "issue"]
    memories = [x for x in records if x["_type"] == "memory"]
    assert len(issues) == 4 and len(memories) == 16
    assert {x["id"] for x in issues} == {
        "web-app-a1b", "web-app-b2c", "web-app-abcdef", "web-app-d4e",
    }
    assert {x["key"] for x in memories} == KEYS
    values = {x["key"]: x["value"] for x in memories}
    assert values["empty-value"] == ""
    assert values["fixture-key"] == "Remembered context"
    dependent = next(x for x in issues if x["id"] == "web-app-b2c")
    assert dependent["title"] == "Dependent work — 記憶"
    assert dependent["description"] == "Body\nSecond line"
    assert dependent["design"] == "A design" and dependent["acceptance_criteria"] == "A check"
    assert dependent["metadata"] == {"list": [1, "value"], "custom": {"flag": True}}
    assert dependent["assignee"] == "fixture-worker" and dependent["estimated_minutes"] == 20
    assert dependent["external_ref"] == "gh-fixture-123"
    assert dependent["labels"] == ["one", "two"]
    assert len(dependent["dependencies"]) == 1
    assert dependent["dependencies"][0]["depends_on_id"] == "web-app-a1b"
    assert dependent["dependencies"][0]["type"] == "blocks"
    assert len(dependent["comments"]) == 1
    assert dependent["comments"][0]["author"] == "fixture-commenter"
    assert dependent["comments"][0]["text"] == "A preserved comment\nSecond line"
    assert next(x for x in issues if x["id"] == "web-app-a1b")["status"] == "closed"
    assert next(x for x in issues if x["id"] == "web-app-abcdef")["metadata"]["unicode"] == "記憶"
    assert next(x for x in issues if x["id"] == "web-app-d4e")["event_kind"] == "fixture.started"
    assert not list((ROOT / "temporary").iterdir())
    print("PASS exact private producer 76fde9c9, canonical binary, 4 Issue/16 Memory genuine export, receipts and cleanup")


if __name__ == "__main__":
    main()
