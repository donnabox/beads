# Iris ordinary-producer corpus generation — attempt01 PASS

Execution owner Janet, 2026-10-17 23:29–23:31 PDT. This is **producer-only generation**, not import activation or installed graph-mode qualification. Immutable recipe: [coordination source](https://github.com/donnabox/agent-coordination/blob/8b5e8917bbbef7da5a8063214f1c278393a06bc8/context/iris/producer-generation-handoff-20261018T0628Z.md), SHA256 `52b7ea737cbab43ad5b519773b0991cb6a822f9305dc28de15ce3621aff449b6`.

Fresh private clone `/Users/dbox/.local/state/iris/producer-private-20261018` has a real `.git` directory, no shared common dir or object alternates, clean exact HEAD `76fde9c9cb0865d430bf12d76fc473490f51128a` and tree `80d2aeb1146a7b3075fbed7a75e31f253032207c`. The damaged shared `/Users/dbox/repos/beads/.git` was not used or changed. Private `core.abbrev=12` produced `76fde9c9cb08` for the canonical `make install-force` build. The ambient `go version` was go1.26.3, while the source-pinned toolchain built the installed binary with go1.26.7; `go version -m` confirms `gms_pure_go`, clean `vcs.revision=76fde9c9` and embedded Dolt/go-mysql-server dependencies.

The frozen d69f6abd generator SHA256 `fa0335aa8fd098ee0c8459f5d36ca4937a8689bb852a2c4eaabaf5512549aa43` ran with profile `completeness`, prefix `web-app`, a private synthetic store, and all `BD_`, `BEADS_`, `DOLT_`, `GIT_` environment keys scrubbed. It emitted exactly 4 Issue and 16 Memory JSONL records. Independent verification confirmed the four expected IDs, all sixteen exact decoded keys, the empty value, `b2c -> a1b` blocks dependency, `fixture-commenter` multiline comment, Unicode/rich Issue fields and all producer command exit codes zero. The temporary directory is empty and no owned `bd`/Dolt/generator process remains. Source HEAD/tree/clean status and binary hash were rechecked after generation.

## Frozen files

| File | SHA256 |
| --- | --- |
| `run.py` | `adfe03752f085ef88fca0bba45032e112b154409a68632f7a6005a15ab373b63` |
| `verify_frozen.py` | `f92b0c0b45f366ebe4f6c9ca28351f3ed98b99f9a8b4ac3c12abe37cecb93126` |
| `generator.py` | `fa0335aa8fd098ee0c8459f5d36ca4937a8689bb852a2c4eaabaf5512549aa43` |
| `install/bd` | `733b2a93b408ee318560146339c97ab3277f98df6c443c8797b1e6e490a715b3` |
| `corpus/ordinary.jsonl` | `66ac6ad8816605b084d2daae65911ca4655b17a937184d98a80e142df1e4d23e` |
| `corpus/producer.json` | `b8087261f6e9107e9de362d87ac32eb5f76e9499b68d59e16a990d55f6d64eee` |
| `runner-receipts.json` | `fa5420c4fc5516c440260ed210ee981e67ad076d42b42f7545eaab2b4e1d9c9e` |
| `runner-result.json` | `2ca3f9f478ae4d6d771904f7d81bef375bb115899df4327ff6f328d3bba7b050` |
| `go.mod` | `3ce31ddbda2ac45d0edbeb31733f4b0ad362d3381ee4dc0af844a80e7b6986ef` |
| `go.sum` | `9e3b1ae46948c3ababd6b4df63865e907ae5afbf00a4ee560a576ac9265e4c71` |
| `logs/make-install-force.stdout` | `059023148f4c74684fd53d570df768f819e3226f8180945a71163c63e7c3b662` |
| `logs/make-install-force.stderr` | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `logs/binary-buildinfo.stdout` | `106404fbed803e738fdf9b10c2646c130d59faf6985500035de2a754913200c9` |
| `logs/binary-version.stdout` | `70fb2cd1fd567ab9a44a45e8e1fd9ff22d27beca90b1e9f092a11c139fb4e801` |
| `logs/compiler.stdout` | `b2fdffd04ae5a836eca9bfdd1d3d10c524b2920dcd5aca393f80258a93a3f0f4` |
| `environment.json` | `00c5237532a3e8116e2eb575dee005edce77d169b882abd6974d351c4e75282f` |

Independent offline `verify_frozen.py` returned PASS, including direct installed-binary buildinfo/version readback and runner log/receipt hashes. `runner-result.json` reports source, tree and binary/generator/fixture hashes. `corpus/producer.json` records per-command receipts and the genuine export hash. No export bytes were hand-edited. Iris owns copying/reviewing these exact bytes into her preparation branch and separately proving import behavior; no source or PR target moved here.
