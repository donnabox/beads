#!/usr/bin/env python3
"""Bounded, observable ordinary-producer generation at frozen source pins."""

from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
CLONE = Path("/Users/dbox/.local/state/iris/producer-private-20261018")
PREP = Path("/Users/dbox/repos/wt/iris/legacy-import-preview3-recovery")
SOURCE = "76fde9c9cb0865d430bf12d76fc473490f51128a"
TREE = "80d2aeb1146a7b3075fbed7a75e31f253032207c"
GENERATOR_SOURCE = "d69f6abd099f10933ff708f3233730011bdc1cfc"
GENERATOR_SHA = "fa0335aa8fd098ee0c8459f5d36ca4937a8689bb852a2c4eaabaf5512549aa43"

ENV = {key: value for key, value in os.environ.items()
       if not key.startswith(("BD_", "BEADS_", "DOLT_", "GIT_"))}
RECEIPTS: list[dict[str, object]] = []


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def run(label: str, argv: list[str], *, cwd: Path | None = None,
        timeout: int = 120, env: dict[str, str] | None = None) -> str:
    out = ROOT / "logs" / f"{label}.stdout"
    err = ROOT / "logs" / f"{label}.stderr"
    started = now()
    print(f"START {label} {started}", flush=True)
    with out.open("wb") as stdout, err.open("wb") as stderr:
        process = subprocess.Popen(argv, cwd=cwd, env=env or ENV,
                                   stdout=stdout, stderr=stderr)
        beginning = time.monotonic()
        last_notice = beginning
        while process.poll() is None:
            elapsed = time.monotonic() - beginning
            if elapsed > timeout:
                process.terminate()
                try:
                    process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait()
                raise TimeoutError(f"{label} exceeded {timeout}s; pid={process.pid}")
            if time.monotonic() - last_notice >= 20:
                print(f"ACTIVE {label} elapsed={elapsed:.0f}s pid={process.pid} "
                      f"stdout={out.stat().st_size} stderr={err.stat().st_size}", flush=True)
                last_notice = time.monotonic()
            time.sleep(1)
    receipt = {"label": label, "argv": argv, "cwd": str(cwd) if cwd else None,
               "start": started, "end": now(), "exit": process.returncode,
               "stdout": str(out), "stdoutSHA256": sha(out),
               "stderr": str(err), "stderrSHA256": sha(err)}
    RECEIPTS.append(receipt)
    (ROOT / "runner-receipts.json").write_text(json.dumps(RECEIPTS, indent=2) + "\n")
    print(f"END {label} exit={process.returncode}", flush=True)
    if process.returncode:
        raise RuntimeError(f"{label} failed; inspect {out} and {err}")
    return out.read_text()


def main() -> None:
    assert (ROOT / "logs").is_dir()
    assert not CLONE.exists(), "private clone path was occupied"
    assert not (ROOT / "corpus").exists(), "corpus path was occupied"
    (ROOT / "environment.json").write_text(json.dumps({
        "start": now(), "scrubbedPrefixes": ["BD_", "BEADS_", "DOLT_", "GIT_"],
        "HOME": ENV.get("HOME"), "PATH": ENV.get("PATH"),
        "GOFLAGS": ENV.get("GOFLAGS"), "GOTOOLCHAIN": ENV.get("GOTOOLCHAIN"),
        "CGO_ENABLED": ENV.get("CGO_ENABLED"), "CC": ENV.get("CC")}, indent=2) + "\n")
    run("clone", ["git", "-c", "core.hooksPath=/dev/null", "clone", "--no-checkout",
                  "--filter=blob:none", "https://github.com/donnabox/beads.git", str(CLONE)], timeout=600)
    assert (CLONE / ".git").is_dir(), "clone did not get private .git directory"
    assert not (CLONE / ".git" / "commondir").exists(), "clone has shared commondir"
    assert not (CLONE / ".git" / "objects" / "info" / "alternates").exists(), "clone has object alternates"
    run("fetch", ["git", "-C", str(CLONE), "-c", "core.hooksPath=/dev/null",
                  "fetch", "--no-tags", "origin", SOURCE], timeout=600)
    run("checkout", ["git", "-C", str(CLONE), "-c", "core.hooksPath=/dev/null",
                     "checkout", "--detach", SOURCE], timeout=600)
    head = run("source-head", ["git", "-C", str(CLONE), "rev-parse", "HEAD"]).strip()
    tree = run("source-tree", ["git", "-C", str(CLONE), "rev-parse", "HEAD^{tree}"]).strip()
    assert (head, tree) == (SOURCE, TREE), (head, tree)
    assert not run("source-clean-before", ["git", "-C", str(CLONE), "status", "--porcelain"]).strip()
    run("abbrev-config", ["git", "-C", str(CLONE), "-c", "core.hooksPath=/dev/null",
                          "config", "--local", "core.abbrev", "12"])
    abbrev = run("abbrev", ["git", "-C", str(CLONE), "rev-parse", "--short", "HEAD"]).strip()
    assert abbrev == "76fde9c9cb08", abbrev
    run("compiler", ["go", "version"])
    run("make-install-force", ["make", f"BUILD_DIR={ROOT / 'build'}",
                               f"INSTALL_DIR={ROOT / 'install'}", "install-force"],
        cwd=CLONE, timeout=1800)
    binary = ROOT / "install" / "bd"
    assert binary.is_file(), "canonical install did not create bd"
    run("binary-buildinfo", ["go", "version", "-m", str(binary)])
    run("binary-version", [str(binary), "version", "--json"], timeout=60)
    (ROOT / "binary.sha256").write_text(sha(binary) + "  install/bd\n")
    for name in ("go.mod", "go.sum"):
        (ROOT / name).write_bytes((CLONE / name).read_bytes())
    generator = ROOT / "generator.py"
    generator.write_text(run("generator-blob", ["git", "-C", str(PREP),
        "-c", "core.hooksPath=/dev/null", "show",
        f"{GENERATOR_SOURCE}:scripts/legacy-import-fixture.py"]))
    assert sha(generator) == GENERATOR_SHA, sha(generator)
    assert run("source-head-after", ["git", "-C", str(CLONE), "rev-parse", "HEAD"]).strip() == SOURCE
    assert run("source-tree-after", ["git", "-C", str(CLONE), "rev-parse", "HEAD^{tree}"]).strip() == TREE
    assert not run("source-clean-after", ["git", "-C", str(CLONE), "status", "--porcelain"]).strip()
    generator_env = dict(ENV)
    generator_env["TMPDIR"] = str(ROOT / "temporary")
    run("generator", [sys.executable, str(generator), "--bd", str(binary),
                      "--source-dir", str(CLONE), "--output", str(ROOT / "corpus"),
                      "--profile", "completeness", "--prefix", "web-app"],
        timeout=600, env=generator_env)
    assert (ROOT / "corpus" / "ordinary.jsonl").is_file()
    assert (ROOT / "corpus" / "producer.json").is_file()
    assert not list((ROOT / "temporary").iterdir()), "owned temp dir not empty"
    assert run("source-head-final", ["git", "-C", str(CLONE), "rev-parse", "HEAD"]).strip() == SOURCE
    assert run("source-tree-final", ["git", "-C", str(CLONE), "rev-parse", "HEAD^{tree}"]).strip() == TREE
    assert not run("source-clean-final", ["git", "-C", str(CLONE), "status", "--porcelain"]).strip()
    assert sha(binary) == (ROOT / "binary.sha256").read_text().split()[0]
    (ROOT / "runner-result.json").write_text(json.dumps({
        "status": "PASS", "end": now(), "source": SOURCE, "tree": TREE,
        "binarySHA256": sha(binary), "generatorSHA256": sha(generator),
        "fixtureSHA256": sha(ROOT / "corpus" / "ordinary.jsonl"),
        "receiptSHA256": sha(ROOT / "corpus" / "producer.json")}, indent=2) + "\n")
    print("PASS producer-only generation; independent corpus verification still required", flush=True)


if __name__ == "__main__":
    try:
        main()
    except BaseException as exc:
        (ROOT / "runner-error.txt").write_text(f"{now()} {type(exc).__name__}: {exc}\n")
        raise
