# PR277: detailed incompatible-ID diagnostics

**Source-incorporated with explicit adaptations; retirement stays held.** [Beads277](https://github.com/donnabox/beads/pull/277) remains freshly OPEN/draft at `397f8a2bb0f6477e547e3e0813a3f178cec52db8`, base275 `4663c16cfed17b8a75090337ed107aaf5b4f94bd`. Main is `6dd6a81f5c733a0b13f92f787e5e16c91affbb1d`; merged/closed/mergeCommit are null. One retained-claim-verified metadata batch queried no checks/actions. This is Beads277, not the unrelated BDP issue.

## Complete five-path contribution

I read [Claudia’s complete receiving](/Users/dbox/Documents/Codex/2026-10-29/claudia-bdp-reference-and-go/outputs/beads277-preservation-disposition.md), full original diff and saved base/head/main bodies in the [evidence archive](/Users/dbox/Documents/Codex/2026-10-29/claudia-bdp-reference-and-go/outputs/beads277-preservation-evidence.zip). All62 manifest payload hashes/sizes and ZIP CRCs match across63 members. All13 present source snapshots match fixed Git objects. The two new test paths return expected128 “not in base4663” errors at base; no original commit was missing and no fetch occurred.

| Path | Selected behavior and preservation |
| --- | --- |
| `internal/storage/graphstore/public_id.go` | The one production-line repair returns the actual `validatePublicID` error instead of replacing it with generic “invalid local Resource ID.” Validation remains before `s.withTx`, so the offending key, grammar reason and replacement instruction survive without database acquisition. The complete238-line resolver/validation tail is byte-identical head→main, SHA `441d8e8359b4a77c66fd772ba9145d03d5929fbcf055faa402a5dbc2f026e2a6`. |
| `internal/storage/graphstore/public_id_diagnostic_test.go` | Whole head/main file is exact. A zero Store tests both exact and compatibility resolvers for `..`/`a//b`: empty returned path, storage validation sentinel, quoted offending key, `dot segment`/`nonempty` reason and explicit compatible replacement instruction. This would touch an unavailable database if admission moved later. |
| `cmd/bd/graph_preview_memory_compatibility_diagnostic_workflow_test.go` | Complete dedicated regression retained. Both engine branches × both flags × both invalid keys × title-only/guarded body variants assert exit2, empty stdout, `invalid_properties`, retryable=false and all diagnostic parts. Each refusal compares all contents of its specified16 authoritative/retained tables, including writer fence/journals/history. The positive guarded exact `TWO` title update retains ID and body. Only two revision arguments gain `=` before their token. |
| `cmd/bd/BUILD.bazel` | New installed-test registration remains exactly once in bd_test amid later unrelated membership growth. |
| `internal/storage/graphstore/BUILD.bazel` | Database-free test registration remains exactly once in graphstore_test amid later membership growth. |

The full original scope is166 additions/1 deletion. No admission grammar, accepted keys, importer, normalization, codec, replacement, protocol pin or schema policy changes belong to this repair. Incompatible IDs are not silently trimmed, encoded, truncated or renamed. This source receiving does not issue a new normative exact-only/abbreviation ruling for other routes.

## Frozen371 correspondence and limits

Fixed371 `31e68fe91a14eaf7968b51380294be166fe046dc` retains both test files byte-identical to main and both registrations exactly once. Its production file differs: in the otherwise preserved resolver tail, the allocation query adds `intrinsic`, `intrinsic-link`, `type-definition` to generic/dependency/informational backings. I verified that this single predicate adaptation accounts for the tail difference. The detailed validation/error return still occurs **before** that query or transaction. Additional reservation/ownership changes above the tail and BUILD growth are not whole-file equality.

This adaptation includes ordinary Type-definition Bead allocations in lookup; it does not classify Type-definition Beads as Links, change275’s caller-root/internal-corruption distinction, or turn malformed caller IDs into invalid-store errors. No broad current Types/Graph admission or transport guarantee follows. The existing installed no-effects oracle covers its **named16 tables**, not an asserted exhaustive census of every later371 table. Historical original both-engine/hook proof is attributed and not rerun; current main/371 CLI/runtime/full conformance remains unqualified by this unit.

## Ownership, dependencies and next boundary

Archived original commit/ancestry evidence retains Donna Box authorship and Agent-Signature; source equality above establishes preservation beyond ancestry. The existing explicit handoff assigned Claudia a **read-only preservation/disposition packet** and retained Janet’s future PR actions. This helper receiving transfers neither implementation nor outward ownership; no role is inferred from the Janet-named branch and no paused Cleo owner is revived.

Parent275 remains a distinct review surface at exactbase4663, already [received separately](/Users/dbox/.local/state/janet/upstream-and-recovery-20261027/overnight-20261029/BEADS-PR275-DISPOSITION-READONLY-0936.md). Keep its branch and holds;277 disposition does not resolve275. Archived277 comments/reviews/threads/closing issues/crossreferences and head-branch-base dependents are empty. Those are bounded historical observations, not fresh exhaustive dependency/discussion checks.

No selected implementation residual was found. Recommend eventual deliberate retirement as incorporated only after the operative draft-close policy is accepted and fresh individual owner/contributor/source/metadata/dependency/close-preflight receiving permits it. Current draft blocker remains operative;372 is proposed/unadopted. Preserve source branch, credit, human review/different-merger requirements where applicable. No automatic ready/close/comment/merge, linked-issue action, new feature campaign or blanket closure follows.

No helper/parser/compiler/test/build/engine, watcher, store, source/index/ref/config/PR/tracker/launch mutation occurred. Fixed immutable Git DATA reads and archive comparisons only; these two new owned report files are the sole writes. Normal hooks and user stores were untouched.
